function getReview() {
    let review = {}

    review["userName"] = prompt("��� ��� ����� ?")
    if (review["userName"] == null) {
        return
    }
    review["comment"] = prompt("�������� ���� �����")
    if (review["comment"] == null) {
        return
    }
    review["date"] = new Date().toLocaleString()

    writeReview(review)
}
const writeReview = review => {
    document.getElementsByClassName('reviews')[0].innerHTML += '    <div class="review-text">\n' +
        `<p> <i> <b>${review['userName']}</b>  ${review['date']}</i></p>` +
        `<p>${review['comment']}</p>` +
        '</div>';
}

import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel';

const webpack = require('webpack');


plugins: [
    new webpack.ProvidePlugin({
        $: 'jquery',
        jQuery: 'jquery',
        'window.jQuery': 'jquery'
    }),
],

$(document).ready(function () {
    $('.owl-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 2
            }
        }
    });
});